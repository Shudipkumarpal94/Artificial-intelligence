location(rony,bangladesh).
location(max,usa).
location(chekz,russia).
location(indro,india).
location(toma,bangladesh).
location(jony,usa).

friends(X,Y):-
    location(X,Z),
    location(Y,Z).

person(X,Y):-
    location(X,Z),
    location(Y,Z).
