student(rony,12501).
student(tom,12502).
student(jony,12503).

id:-
    write("Whose ID do you want to know?"),
    read(X),
    student(X,Y),
    write("ID is : "),
    write(Y).

name:-
    write("Whose name do you want to know?"),
    read(Y),
    student(X,Y),
    write("Name is : "),
    write(X).
