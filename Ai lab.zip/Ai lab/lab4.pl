parent(bob,tom).
parent(tom,tony).
parent(tony,pat).


anchastor(X,Y):-
    parent(X,Y).

anchastor(X,Y):-
    parent(X,Z),
    anchastor(Z,Y).
