student(jems).
father(sam,jems).
lovetoplay(jems,cricket).
govt_emp(sam).
happy(jems).
friend(jems,sam).
parent(sam,jems):-
    father(sam,jems).
happy_family(jems):-
    father(sam,jems),
    happy(jems).


