male(jamil).
male(sohel).
male(rafi).
male(rumi).
male(raj).
male(orko).
male(jarif).
male(ovi).

female(runa).
female(riya).
female(najia).
female(ridima).
female(sufi).
female(saki).

parents(jamil).
parents(runa).
parents(sohel).
parents(rafi).
parents(rumi).
parents(najia).
parents(sufi).
parents(orko).

childern_name(runa,rafi,rumi,riya).
childern_name(jamil,runa,sohel).
childern_name(sohel,najia,ridima).
childern_name(najia,saki,orko).


siblings(rafi,rumi,riya).
siblings(najia,ridima).

mother(riya,runa).
mother(orko,najia).

