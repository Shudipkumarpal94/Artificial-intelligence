parent(pam,bob).
parent(tom,bob).
parent(tom,liza).
parent(bob,anny).
parent(bob,pat).
parent(pat,jim).
male(bob).
male(tom).
male(pat).
male(jim).
female(liza).
female(anny).
female(pam).

brother(X,Y):-
    male(X),
    parent(X,Z),
    parent(Y,Z).

sister(X,Y):-
    female(X),
    parent(X,Z),
    parent(Y,Z).

grandfather(X,Y):-
    male(X),
    parent(X,Z),
    parent(Z,Y).

grandmother(X,Y):-
    female(X),
    parent(X,Z),
    parent(Z,Y).
